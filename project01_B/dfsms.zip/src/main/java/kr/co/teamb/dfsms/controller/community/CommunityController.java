package kr.co.teamb.dfsms.controller.community;

import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;
import kr.co.teamb.dfsms.cmn.PagingService;
import kr.co.teamb.dfsms.service.CommunityService;
import kr.co.teamb.dfsms.vo.CommunityVO;
import kr.co.teamb.dfsms.vo.PageVO;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;




@RestController
@RequestMapping("/community")
public class CommunityController {
	
	@Autowired
	private CommunityService communityService;
	
	@Autowired
	private PagingService pagingService;
	
	@RequestMapping("/list")
	public Map<String, Object> listCommunity(
				@RequestParam Map<String, String> paramMap
				,HttpServletRequest req
			) 
	{
		String cPage = paramMap.get("cPage"); //currentPage
		int totCnt = communityService.totCnt(paramMap); //searchType, searchValue
		//페이징 모듈을 사용해 처리된 값 vo에 setting
		PageVO pageVO = pagingService.makePage(totCnt, cPage);
		//map 초기화시 req 값 셋팅 : searchType, searchValue
		Map<String, String> map = new HashMap<>(paramMap);
		map.put("begin", String.valueOf(pageVO.getBeginPerPage()));
	    map.put("end", String.valueOf(pageVO.getEndPerPage()));
	    //셋팅된 조건값(searchType, searchValue, begin, end)을 함께 넘겨서 조회
	    List<CommunityVO> list = communityService.listCommunity(map);
	    //list 결과를 저장할 res
	    Map<String, Object> res = new HashMap<>();
	    res.put("data", list);
	    res.put("totalItems", pageVO.getTotalRecord());
	    res.put("totalPages", pageVO.getTotalPage());
	    res.put("currentPage", pageVO.getNowPage());
	    res.put("startPage", pageVO.getStartPage());
	    res.put("endPage", pageVO.getEndPage());
		//@RestController에 의해 자동으로 JSON 형식으로 클라이언트에 응답처리 됨
		return res;
	}
	
	@GetMapping("/detail")
	public CommunityVO detailCommunity(@RequestParam("num") int num) {
		communityService.upHit(num);
		return communityService.detailCommunity(num);
	}
	
	@PostMapping("/add")
	public ResponseEntity<?> addCommunity(CommunityVO vo, HttpServletRequest req) {
//		if (!req.getRemoteAddr().equals("192.168.0.39")) {
//			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("업로드 금지");
//		}
		//임시
		vo.setUsrno(1);
		//vo.setUsrnm("관리자");
		communityService.addCommunity(vo);
		return ResponseEntity.ok().body("업로드 성공!");
	}
	
	@PostMapping("/update")
	public ResponseEntity<?> updateCommunity(CommunityVO vo, HttpServletRequest req) {
		int res = communityService.upCommunity(vo);
		if(res > 0) {
			System.out.println("업데이트 성공");
		}
		return ResponseEntity.ok().body("업데이트 성공!");
	}
	
	@GetMapping("/delete")
	public void deleteCommunity(@RequestParam("num") int num) {
		int res = communityService.delCommunity(num);
		if(res > 0) {
			System.out.println("삭제 성공!!");
		}
	}
	
}
