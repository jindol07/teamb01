package kr.co.teamb.dfsms.vo;

import org.apache.ibatis.type.Alias;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Alias("cvo")
public class CommunityVO {
	//공통(공지사항, 리뷰)
	private int boardid;
	private int usrno;
	private String usrnm;
	private String boardtype;
	private String title;
	private String cont;
	private int hit;
	private String rdate;
	private String delyn;
	//리뷰
	private int rating;
}
/*
CREATE TABLE community (
  boardid   number(10) NOT NULL,
  boardtype char(1) NOT NULL,
  usrno     number(10) NOT NULL,
  title     varchar2(50) NOT NULL,
  cont      clob NOT NULL,
  hit       number(10) DEFAULT 0 NOT NULL,
  rdate     date DEFAULT SYSDATE NOT NULL,
  delyn     char(1) DEFAULT 'N' NOT NULL,
  rating    number(1),
  CONSTRAINT COMMUNITY_BOARDID_PK
    PRIMARY KEY (boardid)
);
ALTER TABLE community ADD CONSTRAINT COMMUNITY_USERS_FK FOREIGN KEY (usrno) REFERENCES users (usrno);
*/