package kr.co.teamb.dfsms.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.teamb.dfsms.dao.CommunityDao;
import kr.co.teamb.dfsms.vo.CommunityVO;

@Service
public class CommunityService{
	@Autowired
	private CommunityDao communityDao;
	
	public void addCommunity(CommunityVO vo) {
		communityDao.addCommunity(vo);
	}

	public List<CommunityVO> listCommunity(Map<String, String> map) {
		return communityDao.listCommunity(map);
	}

	public int totCnt(Map<String, String> map) {
		return communityDao.totCnt(map);
	}

	public CommunityVO detailCommunity(int num) {
		return communityDao.detailCommunity(num);
	}

	public void upHit(int num) {
		communityDao.upHit(num);
	}

	public int upCommunity(CommunityVO vo) {
		return communityDao.upCommunity(vo);
	}

	public int delCommunity(int num) {
		return communityDao.delCommunity(num);
	}

}
